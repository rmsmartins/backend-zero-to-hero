package com.rmsmartins.warehousems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehouseMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
