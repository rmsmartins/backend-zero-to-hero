package com.rmsmartins.warehousems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WarehouseMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WarehouseMsApplication.class, args);
	}

}
